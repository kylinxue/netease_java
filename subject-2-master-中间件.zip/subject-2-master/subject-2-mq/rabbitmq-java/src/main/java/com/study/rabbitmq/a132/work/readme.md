# 示例说明

本示例是RabbitMQ 的工作队列示例，通过开启或关闭`channel.basicQos(1);`的注释，演示工作队列的效果