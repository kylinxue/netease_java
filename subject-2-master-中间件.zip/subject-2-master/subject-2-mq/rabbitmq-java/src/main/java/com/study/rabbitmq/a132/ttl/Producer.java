package com.study.rabbitmq.a132.ttl;

// 延时队列
// http://www.rabbitmq.com/ttl.html#per-queue-message-ttl
public class Producer {
}
