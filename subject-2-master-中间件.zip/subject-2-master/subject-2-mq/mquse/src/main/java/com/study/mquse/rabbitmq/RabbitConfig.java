package com.study.mquse.rabbitmq;

/**
 * @Auther: allen
 * @Date: 2019/2/27 11:57
 */
public class RabbitConfig {

    public final static String HOST = "rabbitmq.dn.com";
    public final static int PORT = 5672;
    public final static String USERNAME = "guest";
    public final static String PASSWORD = "guest";

}
