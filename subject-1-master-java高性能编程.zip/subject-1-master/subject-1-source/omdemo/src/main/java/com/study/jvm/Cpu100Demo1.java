package com.study.jvm;

// 处理慢导致的问题(多次jsack定位，比对)
// 递归或死循环计算导致的CPU占用率过高(jstack定位)
public class Cpu100Demo1 {
    public static void main(String[] args) throws InterruptedException {
    }
}
