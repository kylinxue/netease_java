> 无监控不调优 https://github.com/dianping/cat
> 下载通过tomcat部署 http://unidal.org/nexus/content/repositories/releases/com/dianping/cat/cat-home/3.0.0/cat-home-3.0.0.war
> 参考资料：http://www.iigrowing.cn/cat_tong_yi_jian_kong_ping_tai_jian_dan_shi_yong.html

* 当内存占用过高，所有线程处理过慢，会引起CPU也过高
* 当系统资源不足时，JVM的指令也会无法响应