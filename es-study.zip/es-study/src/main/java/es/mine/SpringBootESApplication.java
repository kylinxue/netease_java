package es.mine;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootESApplication {
    public static void main(String[] args) {
        SpringApplication.run(SpringBootESApplication.class, args);
    }
}