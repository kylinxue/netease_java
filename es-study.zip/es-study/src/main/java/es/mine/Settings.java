package es.mine;

public class Settings {
    public static final String DATA_DIR = "D:\\tmp\\lucene_data";
}
